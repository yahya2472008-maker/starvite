import { q } from '../../../../../lib/db.js';
import { kunciCocok, json } from '../../../../../lib/util.js';
import { simpanMusik, hapusMusik } from '../../../../../lib/musik.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

async function periksa(req, params) {
  const { kode } = await params;
  const row = /^[a-z0-9]{8}$/.test(kode) ? q.ambil.get(kode) : null;
  if (!row) return { err: json({ error: 'Undangan tidak ditemukan' }, 404) };
  if (!kunciCocok(row, req.headers.get('x-kunci'))) return { err: json({ error: 'Kunci salah' }, 403) };
  return { kode };
}

export async function PUT(req, { params }) {
  const p = await periksa(req, params);
  if (p.err) return p.err;
  const r = await simpanMusik(p.kode, req);
  return r.error ? json({ error: r.error }, r.status) : json({ ok: true, ukuran: r.ukuran });
}

export async function DELETE(req, { params }) {
  const p = await periksa(req, params);
  if (p.err) return p.err;
  await hapusMusik(p.kode);
  return json({ ok: true });
}
