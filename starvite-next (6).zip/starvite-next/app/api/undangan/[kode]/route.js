import { q } from '../../../../lib/db.js';
import { bersihkan, bacaJson, kunciCocok, json } from '../../../../lib/util.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

const ambil = async (params) => {
  const { kode } = await params;
  return { kode, row: /^[a-z0-9]{8}$/.test(kode) ? q.ambil.get(kode) : null };
};

export async function GET(_req, { params }) {
  const { row } = await ambil(params);
  if (!row) return json({ error: 'Undangan tidak ditemukan' }, 404);
  return json({ d: JSON.parse(row.data), g: JSON.parse(row.tamu) }); // kunci tidak pernah dikirim
}

export async function PUT(req, { params }) {
  const { kode, row } = await ambil(params);
  if (!row) return json({ error: 'Undangan tidak ditemukan' }, 404);
  let body;
  try { body = await bacaJson(req); } catch { return json({ error: 'Permintaan tidak valid' }, 400); }
  if (!kunciCocok(row, body.kunci)) return json({ error: 'Kunci salah' }, 403);
  const bersih = bersihkan(body);
  if (!bersih) return json({ error: 'Data undangan tidak valid' }, 400);
  q.ubah.run(JSON.stringify(bersih.d), JSON.stringify(bersih.g), new Date().toISOString(), kode);
  return json({ kode });
}
