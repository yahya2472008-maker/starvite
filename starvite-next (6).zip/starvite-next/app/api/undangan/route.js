import crypto from 'node:crypto';
import { q, kodeBaru } from '../../../lib/db.js';
import { bersihkan, bacaJson, ipKlien, terlaluBanyak, json } from '../../../lib/util.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(req) {
  if (terlaluBanyak(ipKlien(req))) return json({ error: 'Terlalu banyak percobaan, coba lagi sebentar' }, 429);
  let bersih;
  try { bersih = bersihkan(await bacaJson(req)); } catch { return json({ error: 'Permintaan tidak valid' }, 400); }
  if (!bersih) return json({ error: 'Data undangan tidak valid' }, 400);
  const kode = kodeBaru();
  const kunci = crypto.randomBytes(16).toString('hex');
  const now = new Date().toISOString();
  q.baru.run(kode, kunci, JSON.stringify(bersih.d), JSON.stringify(bersih.g), now, now);
  return json({ kode, kunci }, 201);
}
