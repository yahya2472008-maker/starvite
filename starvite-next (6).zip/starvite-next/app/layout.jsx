import './globals.css';

export const metadata = { title: 'Starvite', description: 'Undangan digital untuk semua jenis acara' };
export const viewport = { width: 'device-width', initialScale: 1 };

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <head>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,400..800&family=Cormorant+Garamond:ital,wght@0,500;0,700;1,500;1,700&family=DM+Sans:wght@400;500;600&family=Fredoka:wght@500;600&family=Playfair+Display:ital,wght@0,600;0,700;1,500&family=Caveat:wght@600;700&family=Bebas+Neue&family=Press+Start+2P&display=swap" />
      </head>
      <body>{children}</body>
    </html>
  );
}
