import { sajikanMusik } from '../../../lib/musik.js';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function GET(req, { params }) {
  const { kode } = await params;
  if (!/^[a-z0-9]{8}$/.test(kode)) return new Response('Tidak ditemukan', { status: 404 });
  return sajikanMusik(kode, req);
}
export const HEAD = GET;
