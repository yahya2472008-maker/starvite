export default function NotFound() {
  return (
    <main style={{ minHeight: '100vh', display: 'grid', placeItems: 'center', textAlign: 'center', padding: 24, color: '#E8EBF8', background: '#05070F', fontFamily: 'system-ui, sans-serif' }}>
      <div>
        <h1 style={{ margin: 0, fontSize: '2rem' }}>Undangan tidak ditemukan</h1>
        <p style={{ color: '#9AA3C7' }}>Tautan ini salah atau undangannya sudah tidak tersedia. Minta tautan terbaru dari pengundang.</p>
      </div>
    </main>
  );
}
