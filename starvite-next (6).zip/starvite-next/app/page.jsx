import Starvite from '../components/Starvite.jsx';

export default function Halaman() {
  return <Starvite />; // halaman pemilik (editor)
}
