import { notFound } from 'next/navigation';
import Starvite from '../../../components/Starvite.jsx';
import { q } from '../../../lib/db.js';

export const dynamic = 'force-dynamic';
export const metadata = { robots: { index: false, follow: false } };

export default async function HalamanTamu({ params }) {
  const { kode } = await params;
  const row = /^[a-z0-9]{8}$/.test(kode) ? q.ambil.get(kode) : null;
  if (!row) notFound();
  // Data undangan ditanam di halaman; aplikasi otomatis masuk mode tamu.
  const inv = JSON.stringify({ d: JSON.parse(row.data), g: JSON.parse(row.tamu) }).replace(/</g, '\\u003c');
  return <Starvite inv={inv} />;
}
