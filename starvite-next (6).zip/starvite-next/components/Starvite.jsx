'use client';
import Script from 'next/script';
import { MARKUP } from './markup.js';

// Tahap 1: tampilan dan logika asli dipertahankan persis (markup + public/starvite-app.js),
// sementara backend, routing, dan halaman tamu sudah memakai Next.js.
export default function Starvite({ inv }) {
  const html = inv
    ? MARKUP.replace(/(<script id="inv-data" type="application\/json">)[\s\S]*?(<\/script>)/, (m, a, b) => a + inv + b)
    : MARKUP;
  return (
    <>
      <div suppressHydrationWarning dangerouslySetInnerHTML={{ __html: html }} />
      <Script src="/starvite-app.js" strategy="afterInteractive" />
    </>
  );
}
